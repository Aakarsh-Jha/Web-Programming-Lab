from django.shortcuts import render
from .forms import StudentForm

def student_form_view(request):
    details = ""
    percentage = None

    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save(commit=False)
            percentage = student.total_percentage()
            details = f"""
            Name: {student.name}
            DOB: {student.dob}
            Address: {student.address}
            Contact: {student.contact_number}
            Email: {student.email}
            Marks - English: {student.english_marks}, Physics: {student.physics_marks}, Chemistry: {student.chemistry_marks}
            """
    else:
        form = StudentForm()

    return render(request, "students/student_form.html", {"form": form, "details": details, "percentage": percentage})


# Create your views here.
