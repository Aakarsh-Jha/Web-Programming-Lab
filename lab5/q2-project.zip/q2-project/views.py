from django.shortcuts import render
from datetime import date
from .forms import PromotionForm

def promotion_view(request):
    result = None
    if request.method == "POST":
        form = PromotionForm(request.POST)
        if form.is_valid():
            doj = form.cleaned_data['date_of_joining']
            today = date.today()
            experience_years = (today - doj).days // 365

            if experience_years >= 5:
                result = "YES"
            else:
                result = "NO"
    else:
        form = PromotionForm()

    return render(request, "employees/promotion.html", {"form": form, "result": result})


# Create your views here.
