from django.db import models

class Employee(models.Model):
    employee_id = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=100)
    date_of_joining = models.DateField()

    def __str__(self):
        return self.employee_id


# Create your models here.
