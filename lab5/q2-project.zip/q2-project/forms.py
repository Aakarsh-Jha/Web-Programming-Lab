from django import forms
from .models import Employee

class PromotionForm(forms.Form):
    employee_id = forms.ModelChoiceField(queryset=Employee.objects.all())
    date_of_joining = forms.DateField(widget=forms.TextInput(attrs={'placeholder': 'YYYY-MM-DD'}))
